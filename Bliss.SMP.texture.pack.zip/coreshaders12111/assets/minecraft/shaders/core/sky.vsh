#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:blissskysig.glsl>
in vec3 Position;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec3 blissDir;out vec4 blissFar;out vec4 blissNear;void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);blissDir=Position.y<0.0?Position+vec3(0.0,12.0,0.0):Position;blissFar=vec4(0.0);blissNear=vec4(0.0);float kYbQPYO;if(Position.y>0.0&&pxvjlkxIF(FogEnvironmentalStart,FogEnvironmentalEnd,kYbQPYO)==awAAFIauG){vec2 VztwdvVbRp=vec2(0.0);if(gl_VertexID>0){float sAkBTAEsi=float(gl_VertexID-1)*0.78539816;VztwdvVbRp=2.0*vec2(cos(sAkBTAEsi),sin(sAkBTAEsi));}gl_Position=vec4(VztwdvVbRp,0.99999,1.0);mat4 uhDMfeodQ=inverse(ProjMat*ModelViewMat);blissFar=uhDMfeodQ*vec4(VztwdvVbRp,1.0,1.0);blissNear=uhDMfeodQ*vec4(VztwdvVbRp,-1.0,1.0);}}
