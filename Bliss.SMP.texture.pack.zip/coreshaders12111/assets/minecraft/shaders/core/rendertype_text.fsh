#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:blissscreenfx.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;flat in int screenMode;flat in ivec2 screenData;flat in vec2 screenAnchor;out vec4 fragColor;bool neqDHwBZ(vec4 JesbMmgO){ivec4 ijcpfuiXA=ivec4(JesbMmgO*255.0+0.5);return ijcpfuiXA.a==12&&(ijcpfuiXA.b==200||ijcpfuiXA.b==201)&&(ijcpfuiXA.r==96||ijcpfuiXA.r==160)&&(ijcpfuiXA.g==96||ijcpfuiXA.g==160);}void main(){vec4 JesbMmgO=texture(Sampler0,texCoord0);if(screenMode>0){if(!neqDHwBZ(JesbMmgO)){discard;}vec4 RNAtcLMcxx=kyWClFwV(gl_FragCoord.xy/ScreenSize,GameTime*1200.0,screenMode,screenData,screenAnchor);if(RNAtcLMcxx.a<0.002){discard;}fragColor=vec4(clamp(RNAtcLMcxx.rgb/RNAtcLMcxx.a,0.0,1.0),RNAtcLMcxx.a);return;}vec4 color=JesbMmgO*vertexColor*ColorModulator;if(color.a<0.1){discard;}fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
