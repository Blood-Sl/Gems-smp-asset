#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:blissskysig.glsl>
in vec4 vertexColor;out vec4 fragColor;void main(){vec4 color=vertexColor;if(color.a==0.0){discard;}if(all(greaterThan(color.rgb,vec3(0.999)))&&ColorModulator!=vec4(1.0)){float kYbQPYO;if(pxvjlkxIF(FogEnvironmentalStart,FogEnvironmentalEnd,kYbQPYO)!=mgFpdON)discard;}fragColor=color*ColorModulator;}
