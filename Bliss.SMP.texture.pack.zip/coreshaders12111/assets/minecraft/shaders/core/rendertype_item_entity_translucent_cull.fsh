#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:blissskyboxengine.glsl>
#moj_import <minecraft:blissendrod.glsl>
#moj_import <minecraft:blissgoldmote.glsl>
#moj_import <minecraft:blissholoearth.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec4 vertexColor;in vec2 texCoord0;in vec2 texCoord1;in vec2 shardLocal;in vec3 shardRel;in vec2 holoCorner;flat in vec4 baseColor;out vec4 fragColor;bool tngfwHE=false;
#define DdXsWAenC 0.45
#define fQzYsME 0.70
float ZfQRBDhYlm(vec4 JesbMmgO){vec4 ijcpfuiXA=JesbMmgO*255.0;float HZrYsKYHo=floor(ijcpfuiXA.g-200.0+0.5);bool PsHuDiQ=abs(ijcpfuiXA.a-243.0)<0.5;bool qHefqONes=abs(ijcpfuiXA.a-242.0)<0.5;bool wwigJyIgen=(PsHuDiQ||qHefqONes)&&abs(ijcpfuiXA.r-255.0)<0.5&&abs(ijcpfuiXA.b-90.0)<0.5&&HZrYsKYHo>=1.0&&HZrYsKYHo<=8.0;tngfwHE=wwigJyIgen&&qHefqONes;return wwigJyIgen?HZrYsKYHo:0.0;}int QNZoPWXvWr(float HZrYsKYHo){int qhgWSKUKwk=int(HZrYsKYHo);if(qhgWSKUKwk==1)return 7;if(qhgWSKUKwk<=3)return 6;return 9-qhgWSKUKwk;}bool kauvMspYXM(ivec2 ELWByiNlVD,int JuwaMAAIl){if(ELWByiNlVD.x<0||ELWByiNlVD.y<0||ELWByiNlVD.x>7||ELWByiNlVD.y>7){return false;}ivec2 hhXsuMUdN=abs(ELWByiNlVD-ivec2(4));int xlLiJZZU=hhXsuMUdN.x+hhXsuMUdN.y;int tYkgVfokQN=max(hhXsuMUdN.x,hhXsuMUdN.y);if(JuwaMAAIl==0)return xlLiJZZU==0;if(JuwaMAAIl==1)return xlLiJZZU<=1;if(JuwaMAAIl==2)return tYkgVfokQN<=1;if(JuwaMAAIl==3)return xlLiJZZU<=2;if(JuwaMAAIl==4||JuwaMAAIl==6)return xlLiJZZU<=3&&tYkgVfokQN<=2;return xlLiJZZU<=3;}bool YpCyxwnEOh(vec2 ADJyJcFq,int JuwaMAAIl){return kauvMspYXM(ivec2(floor(ADJyJcFq*8.0)),JuwaMAAIl);}vec4 mYBvSbOsG(float HZrYsKYHo){int qhgWSKUKwk=int(HZrYsKYHo);if(qhgWSKUKwk==5)return vec4(0.982,0.954,0.926,0.963);if(qhgWSKUKwk==6)return vec4(0.955,0.885,0.812,0.840);if(qhgWSKUKwk==7)return vec4(0.950,0.873,0.792,0.712);if(qhgWSKUKwk==8)return vec4(0.949,0.871,0.789,0.576);return vec4(1.0);}
#define eBvwQovQ (254.0 / 255.0)
#define RkZSiyza vec3(1.00, 0.86, 0.50)
#define kdbQgTBelr 0.25
#define NLmpXmn 0.12
#define BmzAMgDZ 0.46
#define kLwyaTAgW 0.10
#define yAkDDcAD 1.00
#define DxnafkFini 1.35
#define rnGOIvM 0.45
#define jAcbAodA 0.10
#define nKvKXjimi 2.2
#define dvPYNTU 0.30
#define AlpnkeZze 0.40
#define EGKlwTLAQx 0.30
#define hNLmdil vec3(1.00, 0.82, 0.38)
#define aHZLfQSdFG 4
#define MWgIVomUe 0.42
#define IfLdOZE 3.5
#define EuTQIjNW 0.55
#define GEJvoGC 1.45
#define jaurZtxUL vec3(0.78, 0.54, 0.13)
#define gNfBZIhO 0.035
#define mGCBQlGPL 2.0
#define zTDGPYljgz vec3(1.00, 0.80, 0.20)
#define jWQiTBxjE 0.90
#define UjbSgqUpMv 6.28318530718
vec3 fhcFGeyvJ(vec3 rLLKJqx){rLLKJqx=vec3(dot(rLLKJqx,vec3(127.1,311.7,74.7)),dot(rLLKJqx,vec3(269.5,183.3,246.1)),dot(rLLKJqx,vec3(113.5,271.9,124.6)));return fract(sin(rLLKJqx)*43758.5453123);}float UXARaTJ(vec3 rLLKJqx,float ELWByiNlVD){vec3 JuwaMAAIl=floor(rLLKJqx);vec3 qhgWSKUKwk=fract(rLLKJqx);float kUQKtkNu=1e9;float tCMhPSCrV=1e9;for(int GhJyUiPEdA=-1;GhJyUiPEdA<=1;GhJyUiPEdA++){for(int ffbZVNbY=-1;ffbZVNbY<=1;ffbZVNbY++){for(int ZItoZRS=-1;ZItoZRS<=1;ZItoZRS++){vec3 jYHfHUWBN=vec3(float(ZItoZRS),float(ffbZVNbY),float(GhJyUiPEdA));vec3 htGXzCQM=fhcFGeyvJ(JuwaMAAIl+jYHfHUWBN);vec3 YBIKxuPXE=jYHfHUWBN+0.5+AlpnkeZze*sin(ELWByiNlVD*EGKlwTLAQx+UjbSgqUpMv*htGXzCQM);float hhXsuMUdN=length(YBIKxuPXE-qhgWSKUKwk);if(hhXsuMUdN<kUQKtkNu){tCMhPSCrV=kUQKtkNu;kUQKtkNu=hhXsuMUdN;}else if(hhXsuMUdN<tCMhPSCrV){tCMhPSCrV=hhXsuMUdN;}}}}return tCMhPSCrV-kUQKtkNu;}vec3 OGqPaZDN(float ELWByiNlVD){vec3 GYXBOfv=normalize(shardRel);float kDIeSdNtC=ELWByiNlVD*gNfBZIhO;float xdvUMcSS=cos(kDIeSdNtC);float CPlhQUOwPK=sin(kDIeSdNtC);GYXBOfv=vec3(GYXBOfv.x*xdvUMcSS-GYXBOfv.z*CPlhQUOwPK,GYXBOfv.y,GYXBOfv.x*CPlhQUOwPK+GYXBOfv.z*xdvUMcSS);float WBmixriWA=0.0;for(int RNAtcLMcxx=0;RNAtcLMcxx<aHZLfQSdFG;RNAtcLMcxx++){float xWdXNHWZKQ=UjbSgqUpMv*(float(RNAtcLMcxx)+0.5)/float(aHZLfQSdFG);vec3 wYQZWUcgv=normalize(vec3(cos(xWdXNHWZKQ),MWgIVomUe,sin(xWdXNHWZKQ)));WBmixriWA=max(WBmixriWA,pow(max(dot(GYXBOfv,wYQZWUcgv),0.0),IfLdOZE));}vec3 oeWiJfbxRZ=jaurZtxUL*mix(EuTQIjNW,GEJvoGC,WBmixriWA);vec3 EomzwfcEj=shardRel+vec3(CameraBlockPos)-CameraOffset;float mqOTbTB=UXARaTJ(EomzwfcEj*rnGOIvM,ELWByiNlVD);float ZmSOKFFeQx=1.0-smoothstep(jAcbAodA*0.35,jAcbAodA,mqOTbTB);oeWiJfbxRZ=mix(oeWiJfbxRZ,hNLmdil,ZmSOKFFeQx);float PmWOZrL=1.0-smoothstep(0.0,jAcbAodA*nKvKXjimi,mqOTbTB);oeWiJfbxRZ+=hNLmdil*PmWOZrL*dvPYNTU;float LndZAHsIl=eBvwQovQ;vec3 AGEDdJZi=oeWiJfbxRZ*LndZAHsIl;AGEDdJZi+=vec3(1.0)*pow(LndZAHsIl,4.0)*kdbQgTBelr;float jPFayoPtIK=smoothstep(NLmpXmn,NLmpXmn+kLwyaTAgW,LndZAHsIl)*(1.0-smoothstep(BmzAMgDZ-kLwyaTAgW,BmzAMgDZ,LndZAHsIl));AGEDdJZi=mix(AGEDdJZi,RkZSiyza,jPFayoPtIK*yAkDDcAD);return AGEDdJZi*DxnafkFini;}
#define dyUuBmwXY 4.0
#define lPNrFNDCJm 137.0
#define eTRfFWsRlG 91.0
#define ZCaojFPkqr 0.70
#define IzroBzKC 0.034
#define ghqwvxt 2.20
#define kLAjifgfow 0.60
#define wlNhbXDACk 2.05
#define qawPkWChVq 0.27
#define oeszFGL 1.00
#define HOoXGbCX 0.56
#define eaFGbcjMd 1.07
#define NMmdWyaP 0.50
#define vRhyTEZm 5.00
#define iNaHaOn 1.32
#define aKInqhed 0.30
#define OKjhtDriDG 0.010
#define Lyikhqkh 0.24
#define Qvcsybu 0.95
#define zjRYYIPaI 1.08
#define URUfeiHmr vec3(1.00, 0.93, 0.74)
#define StaAcJBb vec3(0.34, 0.17, 0.02)
#define rIVJDGHpO vec3(0.60, 0.32, 0.06)
#define DJCBwTOg vec3(0.78, 0.54, 0.13)
#define SHjzRVe vec3(0.90, 0.70, 0.24)
#define lxbMrFnAYP vec3(0.97, 0.84, 0.46)
vec3 hZJXrXT(float ZItoZRS){vec3 VztwdvVbRp=mix(StaAcJBb,rIVJDGHpO,smoothstep(0.00,0.30,ZItoZRS));VztwdvVbRp=mix(VztwdvVbRp,DJCBwTOg,smoothstep(0.22,0.55,ZItoZRS));VztwdvVbRp=mix(VztwdvVbRp,SHjzRVe,smoothstep(0.50,0.80,ZItoZRS));VztwdvVbRp=mix(VztwdvVbRp,lxbMrFnAYP,smoothstep(0.76,1.00,ZItoZRS));return VztwdvVbRp;}float HPWMAtWGG(vec3 rLLKJqx){return fract(sin(dot(rLLKJqx,vec3(12.9898,78.233,37.719)))*43758.5453123);}float HGUMwoX(vec3 rLLKJqx){vec3 i=floor(rLLKJqx);vec3 qhgWSKUKwk=fract(rLLKJqx);qhgWSKUKwk=qhgWSKUKwk*qhgWSKUKwk*(3.0-2.0*qhgWSKUKwk);float YnvGXGVCH=mix(HPWMAtWGG(i+vec3(0.0,0.0,0.0)),HPWMAtWGG(i+vec3(1.0,0.0,0.0)),qhgWSKUKwk.x);float Xpzucpy=mix(HPWMAtWGG(i+vec3(0.0,1.0,0.0)),HPWMAtWGG(i+vec3(1.0,1.0,0.0)),qhgWSKUKwk.x);float vOFIxHSJof=mix(HPWMAtWGG(i+vec3(0.0,0.0,1.0)),HPWMAtWGG(i+vec3(1.0,0.0,1.0)),qhgWSKUKwk.x);float zwcwOjEm=mix(HPWMAtWGG(i+vec3(0.0,1.0,1.0)),HPWMAtWGG(i+vec3(1.0,1.0,1.0)),qhgWSKUKwk.x);return mix(mix(YnvGXGVCH,Xpzucpy,qhgWSKUKwk.y),mix(vOFIxHSJof,zwcwOjEm,qhgWSKUKwk.y),qhgWSKUKwk.z);}float yRLWJGnZsu(vec3 rLLKJqx){return 0.5333*HGUMwoX(rLLKJqx)+0.2667*HGUMwoX(rLLKJqx*2.03)+0.1333*HGUMwoX(rLLKJqx*4.01)+0.0667*HGUMwoX(rLLKJqx*8.07);}vec4 FwAqvqqjVc(vec2 CkmIettaR,float wvDQzAtQ,float ELWByiNlVD){float efWQfnzMR=length(CkmIettaR)/ZCaojFPkqr;float cWHpqcFdX=1.0-smoothstep(1.0-wvDQzAtQ,1.0+wvDQzAtQ,efWQfnzMR);float bKAevSzPM=min(efWQfnzMR,1.0);float GhJyUiPEdA=sqrt(max(0.0,1.0-bKAevSzPM*bKAevSzPM));vec3 yqOuhtcGm=vec3(CkmIettaR/ZCaojFPkqr,GhJyUiPEdA);float sAkBTAEsi=ELWByiNlVD*IzroBzKC*6.28318530718;float xdvUMcSS=cos(sAkBTAEsi),CPlhQUOwPK=sin(sAkBTAEsi);vec3 QpTJcVTsnD=vec3(yqOuhtcGm.x*xdvUMcSS-yqOuhtcGm.z*CPlhQUOwPK,yqOuhtcGm.y,yqOuhtcGm.x*CPlhQUOwPK+yqOuhtcGm.z*xdvUMcSS);vec3 FgdAjJKhe=QpTJcVTsnD*ghqwvxt;vec3 cjvbWJjal=vec3(yRLWJGnZsu(FgdAjJKhe+vec3(11.3,4.7,19.1)),yRLWJGnZsu(FgdAjJKhe+vec3(31.7,23.9,5.3)),yRLWJGnZsu(FgdAjJKhe+vec3(7.1,41.3,27.7)))-0.5;float tsmbGGJPOU=yRLWJGnZsu(FgdAjJKhe+cjvbWJjal*kLAjifgfow*2.0);tsmbGGJPOU=clamp((tsmbGGJPOU-0.5)*wlNhbXDACk+0.5,0.0,1.0);vec3 JCdlrDEXxT=hZJXrXT(qawPkWChVq+(oeszFGL-qawPkWChVq)*tsmbGGJPOU);JCdlrDEXxT*=mix(HOoXGbCX,eaFGbcjMd,GhJyUiPEdA);JCdlrDEXxT+=URUfeiHmr*pow(1.0-GhJyUiPEdA,3.0)*NMmdWyaP;float YVhHOKa=exp(-max(0.0,efWQfnzMR-1.0)*vRhyTEZm)*(1.0-smoothstep(iNaHaOn-aKInqhed,iNaHaOn,efWQfnzMR));vec3 TFGJJrvfGT=mix(URUfeiHmr*(0.85+0.15*tsmbGGJPOU),JCdlrDEXxT,cWHpqcFdX);TFGJJrvfGT+=URUfeiHmr*YVhHOKa*Lyikhqkh;float LyNgTEUI=mix(clamp(YVhHOKa*Qvcsybu,0.0,1.0),1.0,cWHpqcFdX);return vec4(TFGJJrvfGT*zjRYYIPaI,LyNgTEUI);}
#define oYCisGP 13.2
#define rXxKeia 5.0
#define ppLoByhaDh 0.22
#define JxOxmVBjHV 0.06
#define ZZVUvBoY 0.85
#define ooSSehibv 0.045
#define rGjoKkDq 0.55
#define IKVEiosFgq vec3(0.30, 0.72, 1.00)
#define SteAqzbHSk vec3(0.06, 0.20, 0.36)
#define HQEOyYD 72
#define PjTXfuUzIa vec3(0.50, 0.95, 1.00)
#define LTonQAV 0.55
#define cSoLemHj 0.82
#define nItbnMX 0.32
vec3 SAWQnLpk(vec3 OzpIuOMS,float xdvUMcSS,float CPlhQUOwPK){return vec3(OzpIuOMS.x*xdvUMcSS-OzpIuOMS.z*CPlhQUOwPK,OzpIuOMS.y,OzpIuOMS.x*CPlhQUOwPK+OzpIuOMS.z*xdvUMcSS);}vec4 qyEvfMXzqy(vec2 ElwvCTQlx,vec2 cvtDKaY,vec3 qSsYMKPXbI,vec3 aUIoAhVocI,float ELWByiNlVD){float aMIpqlmh=ElwvCTQlx.x*cvtDKaY.y-cvtDKaY.x*ElwvCTQlx.y;if(abs(aMIpqlmh)<=1e-9)return vec4(0.0);vec3 JHOHTIWW=(qSsYMKPXbI*cvtDKaY.y-aUIoAhVocI*ElwvCTQlx.y)/aMIpqlmh;vec3 caphfVq=(-qSsYMKPXbI*cvtDKaY.x+aUIoAhVocI*ElwvCTQlx.x)/aMIpqlmh;vec3 wHNGMKP=shardRel-holoCorner.x*JHOHTIWW-holoCorner.y*caphfVq;float PHixuQJ=ZCaojFPkqr*length(JHOHTIWW);if(PHixuQJ<1e-4)return vec4(0.0);vec3 sjYcQhF=-wHNGMKP/PHixuQJ;vec3 VGnvTPDzd=normalize(shardRel);float IfHPvhcST=1.0+1.5/oYCisGP;float ijcpfuiXA=dot(sjYcQhF,VGnvTPDzd);float BbhMdrFNZ=ijcpfuiXA*ijcpfuiXA-(dot(sjYcQhF,sjYcQhF)-IfHPvhcST*IfHPvhcST);if(BbhMdrFNZ<0.0)return vec4(0.0);float cFkFBlR=max(0.0,-ijcpfuiXA-sqrt(BbhMdrFNZ));sjYcQhF+=VGnvTPDzd*cFkFBlR;float sAkBTAEsi=ELWByiNlVD*ooSSehibv*6.28318530718;float xdvUMcSS=cos(sAkBTAEsi),CPlhQUOwPK=sin(sAkBTAEsi);vec3 kxTGbfhCd=SAWQnLpk(sjYcQhF,xdvUMcSS,CPlhQUOwPK);vec3 GEnJbbua=SAWQnLpk(VGnvTPDzd,xdvUMcSS,CPlhQUOwPK);vec3 beIHzcdh=SAWQnLpk(normalize(vec3(0.45,0.65,0.62)),xdvUMcSS,CPlhQUOwPK);vec3 XejhaMtYa=kxTGbfhCd*oYCisGP;vec3 gxtXECPkrN=floor(XejhaMtYa);vec3 DfjcHRbAqU=step(0.0,GEnJbbua)*2.0-1.0;vec3 uhDMfeodQ=1.0/max(abs(GEnJbbua),vec3(1e-5));vec3 EHRJGhE=mix(XejhaMtYa-gxtXECPkrN,gxtXECPkrN+1.0-XejhaMtYa,step(0.0,GEnJbbua))*uhDMfeodQ;float jpFSFHh=oYCisGP*oYCisGP;float gRnRQOdYSJ=0.0;vec3 eVaCJhrIT=-GEnJbbua;bool NrPAIVxZw=false;for(int i=0;i<HQEOyYD;i++){vec3 oYrFtejy=gxtXECPkrN+0.5;if(dot(oYrFtejy,oYrFtejy)<=jpFSFHh){NrPAIVxZw=true;break;}if(EHRJGhE.x<EHRJGhE.y&&EHRJGhE.x<EHRJGhE.z){gRnRQOdYSJ=EHRJGhE.x;gxtXECPkrN.x+=DfjcHRbAqU.x;EHRJGhE.x+=uhDMfeodQ.x;eVaCJhrIT=vec3(-DfjcHRbAqU.x,0.0,0.0);}else if(EHRJGhE.y<EHRJGhE.z){gRnRQOdYSJ=EHRJGhE.y;gxtXECPkrN.y+=DfjcHRbAqU.y;EHRJGhE.y+=uhDMfeodQ.y;eVaCJhrIT=vec3(0.0,-DfjcHRbAqU.y,0.0);}else{gRnRQOdYSJ=EHRJGhE.z;gxtXECPkrN.z+=DfjcHRbAqU.z;EHRJGhE.z+=uhDMfeodQ.z;eVaCJhrIT=vec3(0.0,0.0,-DfjcHRbAqU.z);}if(gRnRQOdYSJ>2.0*IfHPvhcST*oYCisGP)break;}if(!NrPAIVxZw)return vec4(0.0);float WBmixriWA=0.35+0.65*max(dot(eVaCJhrIT,beIHzcdh),0.0);float eqLVFiWp=fract(sin(dot(gxtXECPkrN,vec3(12.9898,78.233,37.719)))*43758.5453);WBmixriWA=clamp(WBmixriWA+(eqLVFiWp-0.5)*ppLoByhaDh,0.0,1.0);WBmixriWA=floor(WBmixriWA*rXxKeia+0.5)/rXxKeia;vec3 OJwkBnO=XejhaMtYa+GEnJbbua*gRnRQOdYSJ;vec2 VomaWQMrj=abs(eVaCJhrIT.x)>0.5?OJwkBnO.yz:(abs(eVaCJhrIT.y)>0.5?OJwkBnO.xz:OJwkBnO.xy);vec2 uwUmknG=abs(fract(VomaWQMrj)-0.5);float ikIavFCWn=smoothstep(0.5-JxOxmVBjHV,0.5,max(uwUmknG.x,uwUmknG.y));bool ngNbznX=FltbshBV(normalize(gxtXECPkrN+0.5));vec3 TFGJJrvfGT=ngNbznX?mix(SteAqzbHSk,PjTXfuUzIa,WBmixriWA):mix(SteAqzbHSk*0.7,IKVEiosFgq*LTonQAV,WBmixriWA);TFGJJrvfGT=mix(TFGJJrvfGT,SteAqzbHSk*0.45,ikIavFCWn*ZZVUvBoY);float LyNgTEUI=clamp((ngNbznX?cSoLemHj:nItbnMX)*(0.7+0.3*WBmixriWA)+ikIavFCWn*0.25,0.0,1.0);return vec4(TFGJJrvfGT,LyNgTEUI);}void main(){vec4 JesbMmgO=texture(Sampler0,texCoord0);if(DQXQQhwr(JesbMmgO,baseColor,shardRel,fragColor))return;vec2 mmiGHBdfHb=fwidth(shardLocal)*mGCBQlGPL;vec2 FWJmHpSDgB=JesbMmgO.rg*2.0-1.0;float xtipiIOVA=max(fwidth(length(FWJmHpSDgB)/ZCaojFPkqr),1e-4)*1.1;vec2 pPRDmvkNlj=dFdx(holoCorner);vec2 uyghAOVn=dFdy(holoCorner);vec3 xLujDzpGg=dFdx(shardRel);vec3 MxVwtOoIT=dFdy(shardRel);if(abs(JesbMmgO.a*255.0-dyUuBmwXY)<1.5&&abs(JesbMmgO.b*255.0-eTRfFWsRlG)<4.0){vec4 ABSvYvVV=qyEvfMXzqy(pPRDmvkNlj,uyghAOVn,xLujDzpGg,MxVwtOoIT,GameTime*1200.0);if(ABSvYvVV.a<OKjhtDriDG){discard;}fragColor=ABSvYvVV;return;}if(abs(JesbMmgO.a*255.0-dyUuBmwXY)<1.5&&abs(JesbMmgO.b*255.0-lPNrFNDCJm)<4.0){vec4 qglBbENcBE=FwAqvqqjVc(FWJmHpSDgB,xtipiIOVA,GameTime*1200.0);if(qglBbENcBE.a<OKjhtDriDG){discard;}fragColor=vec4(clamp(qglBbENcBE.rgb,0.0,1.0),qglBbENcBE.a);return;}float HZrYsKYHo=ZfQRBDhYlm(JesbMmgO);if(HZrYsKYHo>0.0){int JuwaMAAIl=QNZoPWXvWr(HZrYsKYHo);vec4 guZECmJxat=mYBvSbOsG(HZrYsKYHo);float fade=vertexColor.a*ColorModulator.a;if(!YpCyxwnEOh(shardLocal,JuwaMAAIl)){if(YpCyxwnEOh(shardLocal+vec2(mmiGHBdfHb.x,0.0),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(-mmiGHBdfHb.x,0.0),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(0.0,mmiGHBdfHb.y),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(0.0,-mmiGHBdfHb.y),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(mmiGHBdfHb.x,mmiGHBdfHb.y),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(-mmiGHBdfHb.x,mmiGHBdfHb.y),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(mmiGHBdfHb.x,-mmiGHBdfHb.y),JuwaMAAIl)||YpCyxwnEOh(shardLocal+vec2(-mmiGHBdfHb.x,-mmiGHBdfHb.y),JuwaMAAIl)){vec3 cVuubKNho=(tngfwHE&&any(lessThan(baseColor.rgb,vec3(0.99))))?baseColor.rgb:zTDGPYljgz;fragColor=vec4(cVuubKNho,jWQiTBxjE*guZECmJxat.a*fade*(tngfwHE?fQzYsME:1.0));return;}discard;}vec3 AGEDdJZi=OGqPaZDN(GameTime*1200.0)*guZECmJxat.rgb;if(tngfwHE&&any(lessThan(baseColor.rgb,vec3(0.99)))){float XcuZAgSi=dot(AGEDdJZi,vec3(0.299,0.587,0.114));AGEDdJZi=baseColor.rgb*XcuZAgSi*1.7+vec3(XcuZAgSi*XcuZAgSi*0.25);}vec4 RNAtcLMcxx=vec4(AGEDdJZi,eBvwQovQ*guZECmJxat.a*fade*(tngfwHE?DdXsWAenC:1.0));RNAtcLMcxx=apply_fog(RNAtcLMcxx,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);fragColor=vec4(clamp(RNAtcLMcxx.rgb,0.0,1.0),RNAtcLMcxx.a);return;}if(FGwcPIVup(JesbMmgO)){fragColor=vec4(MfKBkoYv(normalize(shardRel),GameTime),1.0);return;}if(CnooLDOpzw(JesbMmgO)){fragColor=vec4(auGtExnhFx(normalize(shardRel)),1.0);return;}vec4 color=JesbMmgO*vertexColor*ColorModulator;if(color.a<0.1){discard;}fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
