#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;in vec2 UV0;out vec2 texCoord0;flat out int blissBody;void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);texCoord0=UV0;float ERUYRMwHL=length(ModelViewMat[0].xyz);blissBody=abs(ERUYRMwHL-30.0)<0.5?1:(abs(ERUYRMwHL-20.0)<0.5?2:0);}
