#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:blissskysig.glsl>
uniform sampler2D Sampler0;in vec2 texCoord0;flat in int blissBody;out vec4 fragColor;const vec3 qBkPWjj=vec3(1.00,0.22,0.16);const float hkCFqpcMiQ=1.90;void main(){vec4 color=texture(Sampler0,texCoord0);if(color.a==0.0){discard;}if(blissBody!=0){float kYbQPYO;int RbvDonlRAB=pxvjlkxIF(FogEnvironmentalStart,FogEnvironmentalEnd,kYbQPYO);if(RbvDonlRAB==oLLGkwyWZ||RbvDonlRAB==lYIYbml||RbvDonlRAB==CIwhDhzdm||RbvDonlRAB==awAAFIauG)discard;if(RbvDonlRAB==HqueXQh&&kYbQPYO<23.5)discard;if(RbvDonlRAB==LTYyqtO){if(blissBody==1)discard;fragColor=vec4(color.rgb*ColorModulator.rgb*qBkPWjj*hkCFqpcMiQ,color.a);return;}}fragColor=color*ColorModulator;}
