#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:blissskysig.glsl>
uniform sampler2D Sampler0;in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec2 texCoord0;in vec4 vertexColor;in vec4 partColor;in float partBright;out vec4 fragColor;
#define HfQiCcuu 1.4
void main(){vec4 RfczVUCyN=texture(Sampler0,texCoord0);vec4 color=RfczVUCyN*vertexColor*ColorModulator;if(color.a<0.1){discard;}if(partBright>0.5&&textureSize(Sampler0,0).x>128){float kYbQPYO;int vJBcdsv=pxvjlkxIF(FogEnvironmentalStart,FogEnvironmentalEnd,kYbQPYO);if(vJBcdsv==wiZjBMkHh||vJBcdsv==XJmLkpX)color.rgb*=HfQiCcuu;}fragColor=apply_fog(color,sphericalVertexDistance,cylindricalVertexDistance,FogEnvironmentalStart,FogEnvironmentalEnd,FogRenderDistanceStart,FogRenderDistanceEnd,FogColor);}
