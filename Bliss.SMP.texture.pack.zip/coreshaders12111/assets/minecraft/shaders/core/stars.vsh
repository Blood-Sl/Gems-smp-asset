#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;out vec3 blissDir;const float yuzXQKW=2.54146;void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);float xdvUMcSS=cos(yuzXQKW),CPlhQUOwPK=sin(yuzXQKW);vec3 ofzoOBUiKo=vec3(Position.x,Position.y*xdvUMcSS-Position.z*CPlhQUOwPK,Position.y*CPlhQUOwPK+Position.z*xdvUMcSS);blissDir=vec3(-ofzoOBUiKo.z,ofzoOBUiKo.y,ofzoOBUiKo.x);}
