#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:blissskysig.glsl>
#moj_import <minecraft:blissritual.glsl>
in vec3 blissDir;out vec4 fragColor;const vec3 WdEkBDofd=vec3(1.00,0.36,0.32);const float EjxukdCtwf=1.25;void main(){float kYbQPYO;int RbvDonlRAB=pxvjlkxIF(FogEnvironmentalStart,FogEnvironmentalEnd,kYbQPYO);if(RbvDonlRAB==lYIYbml||RbvDonlRAB==CIwhDhzdm||RbvDonlRAB==awAAFIauG||RbvDonlRAB==HqueXQh)discard;if(RbvDonlRAB==LTYyqtO){fragColor=vec4(ColorModulator.rgb*WdEkBDofd*EjxukdCtwf,ColorModulator.a);return;}if(RbvDonlRAB==oLLGkwyWZ){fragColor=vec4(VRQKeFmUw(normalize(blissDir),GameTime*1200.0),ColorModulator.a);return;}fragColor=ColorModulator;}
