#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
in vec3 Position;in vec2 UV0;in vec4 Color;in ivec2 UV2;uniform sampler2D Sampler2;out float sphericalVertexDistance;out float cylindricalVertexDistance;out vec2 texCoord0;out vec4 vertexColor;out vec4 partColor;out float partBright;void main(){gl_Position=ProjMat*ModelViewMat*vec4(Position,1.0);sphericalVertexDistance=fog_spherical_distance(Position);cylindricalVertexDistance=fog_cylindrical_distance(Position);texCoord0=UV0;vertexColor=Color*texelFetch(Sampler2,UV2/16,0);partColor=Color;partBright=min(UV2.x,UV2.y)>=223?1.0:0.0;}
