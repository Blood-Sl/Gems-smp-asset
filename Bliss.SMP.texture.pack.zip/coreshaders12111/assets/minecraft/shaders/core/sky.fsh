#version 330
// Bliss SMP pack - core shaders built for the Bliss plugin, not for editing
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:blissskysig.glsl>
#moj_import <minecraft:blissritual.glsl>
#moj_import <minecraft:blissskies.glsl>
in float sphericalVertexDistance;in float cylindricalVertexDistance;in vec3 blissDir;in vec4 blissFar;in vec4 blissNear;out vec4 fragColor;void main(){float kYbQPYO;int RbvDonlRAB=pxvjlkxIF(FogEnvironmentalStart,FogEnvironmentalEnd,kYbQPYO);bool oPqlKsRcb=blissDir.y>0.0;if(RbvDonlRAB==CIwhDhzdm&&!oPqlKsRcb){fragColor=vec4(0.0,0.0,0.0,1.0);return;}if(RbvDonlRAB==mgFpdON||(!oPqlKsRcb&&RbvDonlRAB!=oLLGkwyWZ&&RbvDonlRAB!=awAAFIauG)){fragColor=apply_fog(ColorModulator,sphericalVertexDistance,cylindricalVertexDistance,0.0,FogSkyEnd,FogSkyEnd,FogSkyEnd,FogColor);return;}vec3 yqOuhtcGm=normalize(blissDir);if(RbvDonlRAB==awAAFIauG){if(!oPqlKsRcb)discard;yqOuhtcGm=normalize(blissFar.xyz/blissFar.w-blissNear.xyz/blissNear.w);}vec3 cDvLNwX=KxTjlaR(RbvDonlRAB,kYbQPYO,yqOuhtcGm,GameTime*1200.0,ColorModulator.rgb,FogColor.rgb,tPCclBGiXq(FogEnvironmentalEnd));if(RbvDonlRAB==CIwhDhzdm)cDvLNwX*=smoothstep(0.42,0.80,yqOuhtcGm.y);fragColor=vec4(cDvLNwX,1.0);}
